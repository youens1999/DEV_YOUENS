#!/bin/bash

sqlite3 $1 < setup.sql
